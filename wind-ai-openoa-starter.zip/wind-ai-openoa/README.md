# Wind AI + OpenOA 基础项目

这是一个面向 **风电 SCADA 数据处理、功率预测和异常检测** 的基础工程。

当前阶段完成：

- 使用 OpenOA 3.2；
- 使用 OpenOA 官方示例中的 ENGIE La Haute Borne 数据；
- 自动下载并解压 35.1 MB 数据包；
- 将 SCADA、场站电表、限电/可利用率、资产和再分析气象数据加载为 `PlantData`；
- 提供数据检查、特征构建和一个最小机器学习基线；
- 提供 Conda、pip、Docker Compose 三种启动方式。

## 数据说明

数据源：ENGIE La Haute Borne 风电场开放数据，经 OpenOA 官方示例整理。

- 时间范围：2014–2015 年；
- 风机数量：4 台；
- SCADA 粒度：10 分钟；
- 主要字段：功率、风速、风向、机舱相对风向、温度、桨距角；
- 附加数据：场站电表、可利用率/限电、资产信息、ERA5 与 MERRA-2 再分析数据；
- 数据许可：Open Licence 2.0。

官方数据文件：

`https://github.com/NatLabRockies/OpenOA/raw/refs/heads/main/examples/data/la_haute_borne.zip`

## 推荐环境

OpenOA 3.2 官方支持 Python 3.9–3.12。本项目固定使用 **Python 3.11**。

### 方式一：Conda

```bash
conda env create -f environment.yml
conda activate wind-ai-openoa
python scripts/download_data.py
python scripts/check_project.py
```

启动 Jupyter：

```bash
jupyter lab
```

### 方式二：venv + pip

```bash
python3.11 -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/download_data.py
python scripts/check_project.py
```

### 方式三：Docker Compose

```bash
docker compose build
docker compose run --rm app python scripts/download_data.py
docker compose run --rm app python scripts/check_project.py
docker compose up jupyter
```

浏览器访问 `http://localhost:8888`。该开发配置未设置 Jupyter Token，仅建议本机使用。

## 第一次运行

```bash
python scripts/download_data.py
```

预期得到：

```text
data/raw/la_haute_borne/
├── la-haute-borne-data-2014-2015.csv
├── plant_data.csv
├── merra2_la_haute_borne.csv
├── era5_wind_la_haute_borne.csv
└── la-haute-borne_asset_table.csv
```

验证 OpenOA 数据对象：

```bash
python scripts/check_project.py
```

训练最小基线模型：

```bash
python scripts/train_baseline.py
```

模型和指标会写入：

```text
models/power_baseline.joblib
models/power_baseline_metrics.json
```

## 项目结构

```text
wind-ai-openoa/
├── config/plant_meta.yml       # OpenOA 字段映射
├── data/                       # 原始数据和处理后数据
├── models/                     # 模型与指标输出
├── notebooks/00_quickstart.ipynb
├── scripts/
│   ├── download_data.py
│   ├── check_project.py
│   └── train_baseline.py
├── src/wind_ai/
│   ├── paths.py
│   ├── openoa_loader.py
│   └── features.py
├── tests/
├── Dockerfile
├── docker-compose.yml
├── environment.yml
└── requirements.txt
```

## 下一步

基础环境确认后，建议依次加入：

1. 时间切分的功率预测评估；
2. XGBoost/LightGBM 模型；
3. 基于功率预测残差的异常检测；
4. Streamlit 仪表板；
5. FastAPI 在线预测接口。

## 来源与许可

OpenOA：BSD-3-Clause。

示例数据：基于 ENGIE La Haute Borne 开放数据，由 OpenOA 仓库随示例提供，数据目录声明其采用 Open Licence 2.0。请在发布报告、模型或衍生数据时保留数据来源说明。
