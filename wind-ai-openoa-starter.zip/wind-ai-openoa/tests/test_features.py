import numpy as np
import pandas as pd

from wind_ai.features import FEATURE_COLUMNS, build_power_features


def test_build_power_features() -> None:
    frame = pd.DataFrame(
        {
            "Date_time": pd.date_range("2025-01-01", periods=3, freq="10min"),
            "Wind_turbine_name": ["T1"] * 3,
            "Ws_avg": [5.0, 6.0, 7.0],
            "Va_avg": [0.0, 90.0, 180.0],
            "Wa_avg": [0.0, 90.0, 180.0],
            "Ot_avg": [10.0, 11.0, 12.0],
            "Ba_avg": [1.0, 1.0, 1.0],
            "P_avg": [100.0, 200.0, 300.0],
        }
    )
    result = build_power_features(frame)
    assert len(result) == 3
    assert set(FEATURE_COLUMNS).issubset(result.columns)
    assert np.isclose(result.loc[0, "Va_avg_sin"], 0.0)
