#!/usr/bin/env python3
"""Train a small, CPU-friendly wind-turbine power baseline."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from wind_ai.features import FEATURE_COLUMNS, TARGET_COLUMN, build_power_features
from wind_ai.openoa_loader import load_dataframes
from wind_ai.paths import MODELS_DIR


def main() -> int:
    scada = load_dataframes()["scada"]
    dataset = build_power_features(scada)

    # Time-ordered split avoids leaking future observations into training.
    split = int(len(dataset) * 0.8)
    train = dataset.iloc[:split]
    test = dataset.iloc[split:]

    model = HistGradientBoostingRegressor(
        learning_rate=0.08,
        max_iter=250,
        max_leaf_nodes=31,
        l2_regularization=0.1,
        random_state=42,
    )
    model.fit(train[FEATURE_COLUMNS], train[TARGET_COLUMN])
    predictions = model.predict(test[FEATURE_COLUMNS])

    metrics = {
        "train_rows": int(len(train)),
        "test_rows": int(len(test)),
        "mae_kw": float(mean_absolute_error(test[TARGET_COLUMN], predictions)),
        "rmse_kw": float(mean_squared_error(test[TARGET_COLUMN], predictions) ** 0.5),
        "r2": float(r2_score(test[TARGET_COLUMN], predictions)),
        "features": FEATURE_COLUMNS,
    }

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODELS_DIR / "power_baseline.joblib")
    (MODELS_DIR / "power_baseline_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
