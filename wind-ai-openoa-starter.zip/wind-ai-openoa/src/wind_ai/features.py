"""Feature preparation for the first power-prediction baseline."""

from __future__ import annotations

import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    "Ws_avg",
    "Va_avg_sin",
    "Va_avg_cos",
    "Wa_avg_sin",
    "Wa_avg_cos",
    "Ot_avg",
    "Ba_avg",
    "hour_sin",
    "hour_cos",
    "month_sin",
    "month_cos",
]
TARGET_COLUMN = "P_avg"


def build_power_features(scada: pd.DataFrame) -> pd.DataFrame:
    required = {
        "Date_time",
        "Wind_turbine_name",
        "Ws_avg",
        "Va_avg",
        "Wa_avg",
        "Ot_avg",
        "Ba_avg",
        "P_avg",
    }
    missing = sorted(required.difference(scada.columns))
    if missing:
        raise ValueError(f"SCADA 数据缺少字段：{missing}")

    frame = scada.loc[:, sorted(required)].copy()
    frame["Date_time"] = pd.to_datetime(frame["Date_time"])

    for angle in ("Va_avg", "Wa_avg"):
        radians = np.deg2rad(frame[angle])
        frame[f"{angle}_sin"] = np.sin(radians)
        frame[f"{angle}_cos"] = np.cos(radians)

    hour = frame["Date_time"].dt.hour + frame["Date_time"].dt.minute / 60.0
    month = frame["Date_time"].dt.month
    frame["hour_sin"] = np.sin(2 * np.pi * hour / 24)
    frame["hour_cos"] = np.cos(2 * np.pi * hour / 24)
    frame["month_sin"] = np.sin(2 * np.pi * month / 12)
    frame["month_cos"] = np.cos(2 * np.pi * month / 12)

    # Remove obviously impossible values before model training.
    frame = frame.loc[
        frame["Ws_avg"].between(0, 40)
        & frame["P_avg"].between(-100, 2500)
    ].dropna(subset=FEATURE_COLUMNS + [TARGET_COLUMN])

    return frame.sort_values("Date_time").reset_index(drop=True)
